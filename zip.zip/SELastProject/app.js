var express = require('express');
var app = express();
app.use(express.static('public'));
app.post('/news', (req,res) => {
    const news = req.body;
    const news_title1 = req.body.news_title1;
    const news_body1 = news.news_body1;
    const news_title2 = req.body.news_title2;
    const news_body2 = news.news_body2;

    var dict = [];
    dict.push({
        news_title1 : news_body1,
        news_title2 : news_body2
    });
    res.send(dict);
});

app.listen(8000);