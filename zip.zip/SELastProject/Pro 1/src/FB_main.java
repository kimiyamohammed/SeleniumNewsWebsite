import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class FB_main {
    static String T1, T2, B1, B2;
    public static void main(String[] args) {

        System.setProperty("webdriver.chrome.driver","chromedriver.exe");


        WebDriver newsdriver = new ChromeDriver();
        newsdriver.navigate().to("http://www.awrambatimes.com");
        WebElement title2 = newsdriver.findElement(By.xpath("//*[@id='post-17045']/div/h2/a"));
        WebElement body2 = newsdriver.findElement(By.xpath("//*[@id='post-17045']/div/div[3]"));
        T2 = title2.getText();
        B2 = body2.getText();

        WebDriver driver = new ChromeDriver();
        driver.navigate().to("https://www.ethiopianreporter.com/zena");
        WebElement title1 = driver.findElement(By.xpath("//*[@id='block-gavias-kama-content']/div/div/div/div/div[1]/article/div/div[2]/h3/a"));
        WebElement body1 = driver.findElement(By.xpath("//*[@id='block-gavias-kama-content']/div/div/div/div/div[1]/article/div/div[2]/div[2]/div"));
        T1 = title1.getText();
        B1 = body1.getText();

        WebDriver mydriver = new ChromeDriver();
        mydriver.navigate().to("Public\\indexclass.html");
        WebElement goBtn = newsdriver.findElement(By.id("go"));
        goBtn.click();

        try {
            Thread.sleep(10000);
        }catch (Exception E){

        }
        driver.close();
        newsdriver.close();
    }
    public static void sendData(String news_title1, String news_title2, String news_body1, String news_body2) throws  MalformedURLException, ProtocolException, IOException {
        String data1 = "news_title1="+T1;
        String data2 = "news_body1="+B1;

        String data3 = "news_title2="+T2;
        String data4 = "news_body2="+B2;

        URL url = new URL("http://localhost:8000/news");
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("POST");
        con. setDoOutput(true);
        con.getOutputStream().write(data1.getBytes("UTF-8"));
        con.getOutputStream().write(data2.getBytes("UTF-8"));
        con.getOutputStream().write(data3.getBytes("UTF-8"));
        con.getOutputStream().write(data4.getBytes("UTF-8"));
        con.getInputStream();

    }
}
